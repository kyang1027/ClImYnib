import os

def extract_first_pdb_block(input_file):
    pdb_lines = []
    in_pdb_block = False

    for line in input_file:
        if line.startswith("ATOM"):
            in_pdb_block = True
            pdb_lines.append(line)
        elif line.startswith("END") and in_pdb_block:
            in_pdb_block = False
            pdb_lines.append(line)
            return pdb_lines  # 返回第一个PDB块

def save_as_pdb(output_folder, file_name, pdb_content):
    with open(f"{output_folder}/{file_name}.pdb", 'w') as f:
        f.writelines(pdb_content)

def process_dok_file(input_file, output_folder):
    with open(input_file, 'r') as f:
        dok_content = f.readlines()

    pdb_content = extract_first_pdb_block(dok_content)  # 提取第一个PDB块

    if pdb_content:
        pdb_file_name = os.path.splitext(os.path.basename(input_file))[0]
        save_as_pdb(output_folder, pdb_file_name, pdb_content)

def process_all_dok_files(input_folder, output_folder):
    for file_name in os.listdir(input_folder):
        if file_name.endswith(".dok"):
            dok_file = os.path.join(input_folder, file_name)
            process_dok_file(dok_file, output_folder)

# 使用示例
def main():
    input_folder = r'G:\1-10-21\3admet\ledock\PAK4\dok'  # 包含多个DOK文件的目录
    output_folder = r'G:\1-10-21\3admet\ledock\PAK4\pdb'  # 设置你想要保存的目标文件夹路径

    process_all_dok_files(input_folder, output_folder)

if __name__ == "__main__":
    main()
