import numpy as np

# 读取数据文件
data = np.loadtxt('1.txt', delimiter='\t')

# 分离实验值和预测值
experimental_values = data[:, 0]
predicted_values = data[:, 1]

# 使用 numpy 的 polyfit 函数进行线性拟合
slope, intercept = np.polyfit(experimental_values, predicted_values, 1)

# 输出拟合线的方程
print(f"The equation of the fitted line is: y = {slope:.5f}x + {intercept:.5f}")
